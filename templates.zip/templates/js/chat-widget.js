document.addEventListener('DOMContentLoaded', function() {
    const chatWidget = document.querySelector('.chat-widget');
    const chatBox = document.querySelector('.chat-box');
    const toggleBtn = document.querySelector('.chat-toggle-btn');
    const closeBtn = document.querySelector('.chat-close-btn');
    const chatInputArea = document.querySelector('.chat-input');
    const chatInput = document.querySelector('#chat-input-field');
    const sendBtn = document.querySelector('#chat-send-btn');
    const messagesContainer = document.querySelector('.chat-messages');

    let isChatOpen = false;
    let awaitingFeedback = false;

    // Predefined troubleshooting steps
    const troubleshootingSteps = {
        "App Not Working": "Please try clearing the cache and restarting the app. If the issue persists, check for updates in the app store.",
        "Location Issue": "Ensure your GPS is enabled and location permissions are granted for the app in your phone settings.",
        "Login Issue": "Check your internet connection and verify your credentials. If you forgot your password, use the 'Forgot Password' link."
    };

    // Toggle Chat
    function toggleChat() {
        isChatOpen = !isChatOpen;
        if (isChatOpen) {
            chatBox.style.display = 'flex';
            toggleBtn.innerHTML = '✖'; // Close icon
            toggleBtn.setAttribute('aria-label', 'Close chat');
            
            // Initialize options if it's the first time or empty
            if (messagesContainer.children.length <= 1) {
                showMainOptions();
            }
        } else {
            chatBox.style.display = 'none';
            toggleBtn.innerHTML = '💬'; // Chat icon
            toggleBtn.setAttribute('aria-label', 'Open chat');
        }
    }

    toggleBtn.addEventListener('click', toggleChat);
    closeBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleChat();
    });

    // Show Main Options
    function showMainOptions() {
        const options = ["App Not Working", "Location Issue", "Login Issue", "Other"];
        appendOptions(options, handleMainOptionClick);
    }

    // Handle Main Option Click
    function handleMainOptionClick(option) {
        appendMessage(option, 'user-message');
        
        if (option === "Other") {
            appendMessage("Please describe your issue below.", 'bot-message');
            chatInputArea.style.display = 'flex';
            chatInput.focus();
            awaitingFeedback = false; // We are waiting for text input now
        } else {
            // Show troubleshooting step
            setTimeout(() => {
                appendMessage(troubleshootingSteps[option], 'bot-message');
                askForFeedback();
            }, 500);
        }
    }

    // Ask for Feedback
    function askForFeedback() {
        setTimeout(() => {
            appendMessage("Was this helpful?", 'bot-message');
            appendOptions(["Yes", "No"], handleFeedbackClick);
        }, 500);
    }

    // Handle Feedback Click
    function handleFeedbackClick(option) {
        appendMessage(option, 'user-message');

        if (option === "Yes") {
            setTimeout(() => {
                appendMessage("Thank you! Glad I could help. Have a great day! 👋", 'bot-message');
                // End session visual cue
                chatInputArea.style.display = 'none';
            }, 500);
        } else {
            setTimeout(() => {
                appendMessage("I'm sorry about that. Would you like to connect to a human agent?", 'bot-message');
                appendOptions(["Connect to Agent"], handleAgentConnect);
            }, 500);
        }
    }

    // Handle Agent Connect
    function handleAgentConnect(option) {
        appendMessage(option, 'user-message');
        setTimeout(() => {
            appendMessage("Connecting you to a human agent... Please wait while we transfer your chat.", 'bot-message');
        }, 500);
    }

    // Send Message (For "Other" flow)
    function sendMessage() {
        const messageText = chatInput.value.trim();
        if (messageText === "") return;

        // Append User Message
        appendMessage(messageText, 'user-message');
        chatInput.value = '';
        
        // Hide input again as we process
        chatInputArea.style.display = 'none';

        // Simulate Bot Response (LLM)
        setTimeout(() => {
            // In a real app, this would call your backend API
            const botResponses = [
                "I understand. Based on your description, it sounds like a configuration issue. Please try resetting your preferences.",
                "That sounds unusual. Could you try reinstalling the application to see if that resolves the glitch?",
                "I see. This might be related to a recent server update. Please try again in 10 minutes."
            ];
            const randomResponse = botResponses[Math.floor(Math.random() * botResponses.length)];
            appendMessage(randomResponse, 'bot-message');
            
            // Ask for feedback again
            askForFeedback();
        }, 1500);
    }

    // Append Message to UI
    function appendMessage(text, className) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', className);
        messageDiv.textContent = text;
        messagesContainer.appendChild(messageDiv);
        scrollToBottom();
    }

    // Append Options to UI
    function appendOptions(options, callback) {
        const optionsDiv = document.createElement('div');
        optionsDiv.classList.add('options-container');
        
        options.forEach(option => {
            const btn = document.createElement('button');
            btn.classList.add('option-btn');
            btn.textContent = option;
            btn.addEventListener('click', function() {
                // Remove options after selection (optional, but cleaner)
                optionsDiv.remove(); 
                callback(option);
            });
            optionsDiv.appendChild(btn);
        });

        messagesContainer.appendChild(optionsDiv);
        scrollToBottom();
    }

    // Auto-scroll to bottom
    function scrollToBottom() {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    // Event Listeners for Sending
    sendBtn.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
});
